# AIM Style Toolkit

> **Create presentations and visual reports in the AI Mindset Report style**

## What's Inside

This toolkit contains everything you need to create visual artifacts similar to the [AIM Annual Report 2025](https://aim-report-2025.netlify.app/).

### Files

| File | Description |
|------|-------------|
| `aim-presentation-skill.md` | Claude Code skill for generating presentations |
| `visual-dna.md` | Complete visual style specification |
| `svg-metaphors-catalog.md` | 72+ animated SVG metaphor templates |
| `animation-patterns.md` | GSAP and CSS animation recipes |
| `component-library.md` | React component patterns |

## Quick Start

### 1. Install the Skill

Copy `aim-presentation-skill.md` to your Claude Code skills folder:

```bash
cp aim-presentation-skill.md ~/.claude/skills/
```

### 2. Use the Skill

In Claude Code, invoke:

```
/aim-presentation

Content: [your content/transcript]
Style: dark-red (default) | swiss | neon-cyber
Output: presentation | landing-page | report
```

### 3. Deploy

The skill will generate a complete Vite + React project and deploy to Netlify.

## Visual DNA

### Core Colors

```css
--accent: #DC2626;      /* AIM Red - primary accent */
--bg-dark: #0A0A0A;     /* Deep black background */
--bg-light: #F4F4F5;    /* Light mode background */
--text-light: #F5F5F5;  /* Primary text (dark mode) */
--text-muted: #737373;  /* Secondary text */
```

### Typography

- **Roboto Flex** - Variable font for animated headings
- **IBM Plex Mono** - Technical/mono elements

### Animation Stack

- GSAP 3.14+ with ScrollTrigger
- Framer Motion for React components
- CSS custom properties for variable fonts

## Examples

- [AIM Report 2025](https://aim-report-2025.netlify.app/)
- [Osokin Landing](https://osokin.aimindset.org/)
- [Context Gap Deck](https://anka-session4-w26.netlify.app/)

---

*Created by AI Mindset Labs*
