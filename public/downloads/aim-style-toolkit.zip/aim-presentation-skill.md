# AIM Presentation Generator Skill

> Claude Code skill for creating presentations and visual reports in the AI Mindset style.

---

## SKILL METADATA

```yaml
name: aim-presentation
description: Generate presentations and visual artifacts in AIM Report style
triggers:
  - /aim-presentation
  - /aim-report
  - /aim-visual
inputs:
  - content: Content source (transcript, outline, or topic)
  - style: dark-red | swiss | neon-cyber | paper-minimal
  - output: presentation | landing-page | report | single-metaphor
  - deploy: netlify | local
```

---

## 1. STYLE SELECTOR

### A. DARK RED (Default) — AIM Report Style

```typescript
const DARK_RED = {
  background: "#0A0A0A",
  foreground: "#F5F5F5",
  accent: "#DC2626",
  accentGlow: "rgba(220, 38, 38, 0.4)",
  muted: "#737373",
  dim: "#333333",
  border: "#1A1A1A",
};
```

**Typography:**
- Headlines: `Roboto Flex`, variable weight 100-1000, tracking -0.04em
- Mono: `IBM Plex Mono`, tracking 0.05-0.3em, uppercase
- Variable font animation via `--wght`, `--wdth`, `--opsz`

**Effects:**
- Red glow via `filter: drop-shadow(0 0 20px rgba(220,38,38,0.4))`
- Perspective: `perspective: 1000px` for 3D transforms
- Noise texture overlay at 4% opacity
- Grid patterns with red center crosshairs

### B. SWISS — Clean Business

```typescript
const SWISS = {
  background: "transparent",
  foreground: "currentColor",
  accent: "#D80000",
  muted: "currentColor", // + opacity 0.1-0.3
};
```

### C. NEON CYBER — Tech Forward

```typescript
const NEON_CYBER = {
  background: "#09090b",
  foreground: "#ffffff",
  accent: "#00ff87",
  accentSecondary: "#ff00ff",
  muted: "#333333",
};
```

---

## 2. GENERATION PROCESS

### Step 1: Content Analysis

```
INPUT: [User's content - transcript, outline, topic]

EXTRACT:
1. Key concepts (5-15)
2. Visual metaphors mentioned
3. Narrative arc / structure
4. Quotes / key statements
5. Data points / statistics
```

### Step 2: Structure Design

```
PRESENTATION STRUCTURE:
├── Hero (title, subtitle, CTA)
├── Context Section (problem/opportunity)
├── Main Content (3-7 sections)
│   └── Each: Title + Description + Visual Metaphor
├── Data/Statistics (optional)
├── Summary/Manifesto
└── CTA / Next Steps
```

### Step 3: Metaphor Selection

For each concept, select from the 72+ metaphor library:

| Concept Type | Recommended Metaphors |
|--------------|----------------------|
| Information overload | `bottleneck`, `overflow`, `filter` |
| System architecture | `network`, `stack`, `hierarchy` |
| Transformation | `morph`, `merge`, `split` |
| Connection | `bridge`, `sync`, `handoff` |
| Time/Progress | `timeline`, `phase`, `deadline` |
| Human/Cognitive | `focus`, `burnout`, `clarity` |

### Step 4: Code Generation

Generate a complete React + Vite project:

```
project/
├── index.html          # With fonts, meta tags, noise texture
├── App.tsx             # Main navigation + state
├── components/
│   ├── Hero.tsx        # Landing hero with magnetic tilt
│   ├── Section.tsx     # Content sections
│   ├── Metaphors.tsx   # All SVG visual components
│   └── Navigation.tsx  # Timeline nav + progress
├── lib/
│   └── gsap-config.ts  # GSAP + ScrollTrigger setup
├── data/
│   └── content.ts      # Structured content
├── types.ts            # TypeScript definitions
└── index.css           # Tailwind + custom animations
```

---

## 3. COMPONENT TEMPLATES

### Hero Component

```tsx
export const Hero = ({ title, subtitle }) => {
  const [tilt, setTilt] = useState({ x: 0, y: 0 });

  return (
    <section
      className="relative h-screen flex items-center justify-center bg-[#0A0A0A]"
      onMouseMove={(e) => {
        const x = (e.clientX / window.innerWidth) * 2 - 1;
        const y = (e.clientY / window.innerHeight) * 2 - 1;
        setTilt({ x, y });
      }}
    >
      {/* Grid Background */}
      <div className="absolute inset-0 opacity-20">
        <svg className="w-full h-full">
          <defs>
            <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#DC2626" strokeWidth="0.5" opacity="0.3"/>
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid)" />
        </svg>
      </div>

      <div
        className="z-10 text-center"
        style={{
          transform: `rotateY(${tilt.x * 10}deg) rotateX(${-tilt.y * 10}deg)`,
          transformStyle: 'preserve-3d'
        }}
      >
        <h1 className="text-[10vw] font-black tracking-tighter text-white uppercase">
          {title}
        </h1>
        <div className="mt-8 flex flex-col items-center">
          <span className="w-12 h-[2px] bg-[#DC2626] mb-4" />
          <p className="text-sm font-mono tracking-[0.25em] text-neutral-500 uppercase">
            {subtitle}
          </p>
        </div>
      </div>
    </section>
  );
};
```

### Section with Metaphor

```tsx
export const ContentSection = ({ title, description, metaphorId, index }) => (
  <section className="min-h-screen flex items-center py-20 px-6">
    <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-12 items-center">

      {/* Text */}
      <div className={index % 2 === 0 ? '' : 'lg:order-2'}>
        <span className="font-mono text-xs text-[#DC2626] tracking-widest uppercase mb-4 block">
          Section {String(index + 1).padStart(2, '0')}
        </span>
        <h2 className="text-5xl md:text-7xl font-black tracking-tight text-white mb-6">
          {title}
        </h2>
        <p className="text-lg text-neutral-400 leading-relaxed">
          {description}
        </p>
      </div>

      {/* Visual Metaphor */}
      <div className="relative aspect-square">
        <Metaphor type={metaphorId} />
      </div>

    </div>
  </section>
);
```

### Animated SVG Metaphor

```tsx
export const Metaphor = ({ type }) => {
  const containerRef = useRef<SVGSVGElement>(null);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      // Common animations
      gsap.to(".pulse", {
        scale: 1.1, opacity: 0.5,
        duration: 4, yoyo: true, repeat: -1,
        ease: "sine.inOut"
      });
      gsap.to(".spin-slow", {
        rotation: 360, transformOrigin: "center",
        duration: 60, repeat: -1, ease: "linear"
      });
      gsap.to(".particle-float", {
        y: "random(-20, 20)", x: "random(-10, 10)",
        duration: "random(4, 8)", yoyo: true, repeat: -1,
        ease: "sine.inOut", stagger: 0.1
      });
    }, containerRef);
    return () => ctx.revert();
  }, [type]);

  const renderContent = () => {
    switch (type) {
      case 'bottleneck':
        return (
          <g>
            {/* Funnel shape */}
            <path d="M-60 -60 L-20 0 L-20 60 L20 60 L20 0 L60 -60"
              fill="none" stroke="currentColor" strokeWidth="2" />
            {/* Particles queuing */}
            {[...Array(8)].map((_, i) => (
              <circle key={i} cx={-40 + i*10} cy={-80} r="4"
                fill="#DC2626" className="particle-float" />
            ))}
          </g>
        );
      // ... more metaphor cases
    }
  };

  return (
    <svg ref={containerRef} viewBox="-100 -100 200 200" className="w-full h-full">
      <defs>
        <filter id="glow">
          <feGaussianBlur stdDeviation="3" result="blur"/>
          <feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge>
        </filter>
      </defs>
      {renderContent()}
    </svg>
  );
};
```

---

## 4. ANIMATION PATTERNS

### Scroll-Triggered Reveal

```typescript
gsap.from(element, {
  scrollTrigger: {
    trigger: element,
    start: "top 80%",
    end: "bottom 20%",
    scrub: 0.5,
  },
  y: 100,
  opacity: 0,
  filter: "blur(10px)",
  duration: 1,
});
```

### Variable Font Animation

```typescript
gsap.to(".vf-anim", {
  "--wght": 900,
  "--wdth": 150,
  duration: 2,
  ease: "power2.inOut",
});
```

### Perspective Grid

```typescript
gsap.to(gridContainer, {
  scrollTrigger: { trigger: section, scrub: 1 },
  rotationX: 60,
  scale: 0.8,
  duration: 2,
});
```

---

## 5. DEPLOYMENT

### Netlify CLI

```bash
# Build
npm run build

# Deploy
netlify deploy --prod --dir=dist
```

### Response to User

After generation, provide:

1. **Live URL**: `https://[project-name].netlify.app`
2. **Source location**: Path to generated project
3. **Key features**: List of sections and metaphors used
4. **Customization guide**: How to modify content

---

## 6. EXAMPLE INVOCATION

```
/aim-presentation

Content: "Our annual report explores 11 tectonic shifts in AI..."

Sections:
1. The Energy Wall - infrastructure constraints
2. Agent Displacement - automation of knowledge work
3. Reasoning Shift - from retrieval to inference
...

Style: dark-red
Output: report
Deploy: netlify
```

---

## 7. RELATED RULES

- `{rule} {presentations} VG Dark Gaming Style`
- `{rule} {presentations} Visual SVG Metaphors Creator`
- `{rule} {AIM} Stacks Visual Landing Pages Creator`
- `{rule} AI Mindset Design Principles – DARK SIMPLE`

---

*Created for AI Mindset Labs • 2026*
