# SVG Metaphors Catalog

> 72+ animated visual metaphors for abstract concepts. Each metaphor is a self-contained React component with GSAP animations.

---

## Quick Reference

### By Category

| Category | Metaphors |
|----------|-----------|
| **Information Flow** | bottleneck, overflow, filter, pipeline, broadcast, aggregate |
| **System Dynamics** | velocity, stagnation, acceleration, momentum, oscillation |
| **Architecture** | silo, hierarchy, network, stack, queue, grid, modular |
| **Connections** | bridge, barrier, gateway, portal, sync, handoff |
| **State** | locked, unlocked, active, pending, complete, error |
| **Transformation** | merge, split, morph, fragment, assembly |
| **Time** | timeline, cycle, phase, deadline, sprint |
| **Cognitive** | focus, distraction, burnout, clarity, confusion |
| **Security** | shield, audit, encryption, firewall, privacy |
| **Philosophy** | abyss_jump, table_leg, carbon_spring, bowstring_tension |

---

## 1. INFORMATION FLOW

### bottleneck
**Concept:** Too many inputs, limited output
**Mechanic:** Funnel narrowing, particles queue

```tsx
export const Bottleneck = () => (
  <svg viewBox="0 0 100 100">
    {/* Funnel walls */}
    <path d="M20 20 L40 50 L40 80 L60 80 L60 50 L80 20"
      fill="none" stroke="currentColor" strokeWidth="2" />

    {/* Queued particles */}
    {[...Array(8)].map((_, i) => (
      <motion.circle
        key={i}
        cx={25 + i * 7}
        cy={15}
        r="3"
        fill="#DC2626"
        animate={{ y: [0, 65, 0], opacity: [1, 1, 0] }}
        transition={{ duration: 3, delay: i * 0.3, repeat: Infinity }}
      />
    ))}

    {/* Output stream */}
    <motion.circle cx="50" cy="90" r="3" fill="currentColor"
      animate={{ y: [-10, 0], opacity: [1, 0] }}
      transition={{ duration: 0.5, repeat: Infinity, repeatDelay: 1 }}
    />
  </svg>
);
```

### overflow
**Concept:** Container exceeds capacity
**Mechanic:** Box filling past top, spillover

```tsx
export const Overflow = () => (
  <svg viewBox="0 0 100 100">
    {/* Container */}
    <rect x="25" y="30" width="50" height="50" fill="none"
      stroke="currentColor" strokeWidth="2" />

    {/* Rising level */}
    <motion.rect x="27" y="78" width="46" fill="#DC2626" opacity="0.6"
      animate={{ height: [0, 60], y: [78, 18] }}
      transition={{ duration: 3, repeat: Infinity, repeatType: "reverse" }}
    />

    {/* Overflow particles */}
    {[...Array(5)].map((_, i) => (
      <motion.circle
        key={i}
        cx={30 + i * 10}
        cy="28"
        r="2"
        fill="#DC2626"
        initial={{ opacity: 0, y: 0 }}
        animate={{ opacity: [0, 1, 0], y: [0, -20] }}
        transition={{ duration: 1, delay: 2 + i * 0.2, repeat: Infinity, repeatDelay: 2 }}
      />
    ))}
  </svg>
);
```

### filter
**Concept:** Selection from noise
**Mechanic:** Grid → single element

```tsx
export const Filter = () => (
  <svg viewBox="0 0 100 100">
    {/* Input noise - many dots */}
    {[...Array(20)].map((_, i) => (
      <circle key={i}
        cx={20 + (i % 5) * 15}
        cy={15 + Math.floor(i / 5) * 10}
        r="3"
        fill="currentColor"
        opacity="0.3"
      />
    ))}

    {/* Filter line */}
    <line x1="10" y1="50" x2="90" y2="50"
      stroke="#DC2626" strokeWidth="2" strokeDasharray="4 4" />
    <text x="50" y="58" textAnchor="middle" fill="#DC2626"
      fontSize="8" fontFamily="monospace">FILTER</text>

    {/* Output - single element */}
    <motion.circle cx="50" cy="75" r="8" fill="#DC2626"
      animate={{ scale: [1, 1.2, 1] }}
      transition={{ duration: 2, repeat: Infinity }}
    />
  </svg>
);
```

### pipeline
**Concept:** Sequential processing
**Mechanic:** Horizontal chain, moving dots

```tsx
export const Pipeline = () => (
  <svg viewBox="0 0 100 100">
    {/* Pipeline stages */}
    {[20, 50, 80].map((x, i) => (
      <rect key={i} x={x - 10} y="40" width="20" height="20"
        fill="none" stroke="currentColor" strokeWidth="1.5" />
    ))}

    {/* Connectors */}
    <line x1="30" y1="50" x2="40" y2="50" stroke="currentColor" />
    <line x1="60" y1="50" x2="70" y2="50" stroke="currentColor" />

    {/* Moving particle */}
    <motion.circle r="4" fill="#DC2626"
      animate={{ cx: [10, 20, 50, 80, 95], cy: 50 }}
      transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
    />
  </svg>
);
```

### broadcast
**Concept:** One to many
**Mechanic:** Center + radiating rings

```tsx
export const Broadcast = () => (
  <svg viewBox="0 0 100 100">
    {/* Center source */}
    <circle cx="50" cy="50" r="8" fill="#DC2626" />

    {/* Radiating rings */}
    {[20, 35, 50].map((r, i) => (
      <motion.circle key={i} cx="50" cy="50" r={r}
        fill="none" stroke="currentColor" strokeWidth="1"
        initial={{ opacity: 0, scale: 0.5 }}
        animate={{ opacity: [0.8, 0], scale: [0.5, 1.5] }}
        transition={{ duration: 2, delay: i * 0.5, repeat: Infinity }}
      />
    ))}
  </svg>
);
```

---

## 2. SYSTEM DYNAMICS

### velocity
**Concept:** Speed of change
**Mechanic:** Horizontal streaks

```tsx
export const Velocity = () => (
  <svg viewBox="0 0 100 100">
    {[...Array(5)].map((_, i) => (
      <motion.line key={i}
        x1="0" y1={30 + i * 10} x2="40" y2={30 + i * 10}
        stroke="#DC2626" strokeWidth="2"
        animate={{ x1: [0, 60], x2: [40, 100] }}
        transition={{ duration: 0.8, delay: i * 0.1, repeat: Infinity }}
      />
    ))}

    {/* Main object */}
    <motion.rect x="70" y="40" width="20" height="20"
      fill="currentColor"
      animate={{ x: [70, 75, 70] }}
      transition={{ duration: 0.5, repeat: Infinity }}
    />
  </svg>
);
```

### momentum
**Concept:** Continuing force
**Mechanic:** Ball rolling with decay

```tsx
export const Momentum = () => (
  <svg viewBox="0 0 100 100">
    {/* Track */}
    <line x1="10" y1="70" x2="90" y2="70" stroke="currentColor" strokeWidth="1" />

    {/* Rolling ball with decay */}
    <motion.circle cy="60" r="10" fill="#DC2626"
      animate={{ cx: [20, 80, 70, 65, 62, 60] }}
      transition={{ duration: 4, repeat: Infinity, ease: "easeOut" }}
    />

    {/* Trail marks */}
    {[20, 35, 50, 60].map((x, i) => (
      <circle key={i} cx={x} cy="70" r="1" fill="currentColor" opacity={0.3 - i * 0.05} />
    ))}
  </svg>
);
```

### oscillation
**Concept:** Back and forth
**Mechanic:** Pendulum swing

```tsx
export const Oscillation = () => (
  <svg viewBox="0 0 100 100">
    {/* Pivot */}
    <circle cx="50" cy="20" r="3" fill="currentColor" />

    {/* Pendulum arm + weight */}
    <motion.g
      style={{ transformOrigin: "50px 20px" }}
      animate={{ rotate: [-30, 30, -30] }}
      transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
    >
      <line x1="50" y1="20" x2="50" y2="70" stroke="currentColor" strokeWidth="2" />
      <circle cx="50" cy="75" r="8" fill="#DC2626" />
    </motion.g>
  </svg>
);
```

---

## 3. STRUCTURE & ARCHITECTURE

### network
**Concept:** Interconnected nodes
**Mechanic:** Graph with edges

```tsx
export const Network = () => {
  const nodes = [
    { x: 50, y: 50 }, // center
    { x: 25, y: 30 }, { x: 75, y: 30 },
    { x: 25, y: 70 }, { x: 75, y: 70 },
  ];

  return (
    <svg viewBox="0 0 100 100">
      {/* Edges */}
      {nodes.slice(1).map((n, i) => (
        <line key={i} x1="50" y1="50" x2={n.x} y2={n.y}
          stroke="currentColor" strokeWidth="1" opacity="0.5" />
      ))}

      {/* Nodes */}
      {nodes.map((n, i) => (
        <motion.circle key={i} cx={n.x} cy={n.y}
          r={i === 0 ? 8 : 5}
          fill={i === 0 ? "#DC2626" : "currentColor"}
          animate={{ scale: [1, 1.1, 1] }}
          transition={{ duration: 2, delay: i * 0.2, repeat: Infinity }}
        />
      ))}
    </svg>
  );
};
```

### hierarchy
**Concept:** Top-down structure
**Mechanic:** Tree / pyramid

```tsx
export const Hierarchy = () => (
  <svg viewBox="0 0 100 100">
    {/* Levels */}
    <circle cx="50" cy="20" r="6" fill="#DC2626" />

    <line x1="50" y1="26" x2="30" y2="44" stroke="currentColor" />
    <line x1="50" y1="26" x2="70" y2="44" stroke="currentColor" />

    <circle cx="30" cy="50" r="5" fill="currentColor" />
    <circle cx="70" cy="50" r="5" fill="currentColor" />

    <line x1="30" y1="55" x2="20" y2="74" stroke="currentColor" />
    <line x1="30" y1="55" x2="40" y2="74" stroke="currentColor" />
    <line x1="70" y1="55" x2="60" y2="74" stroke="currentColor" />
    <line x1="70" y1="55" x2="80" y2="74" stroke="currentColor" />

    {[20, 40, 60, 80].map((x, i) => (
      <circle key={i} cx={x} cy="80" r="4" fill="currentColor" opacity="0.6" />
    ))}
  </svg>
);
```

### stack
**Concept:** Layered system
**Mechanic:** Vertical blocks

```tsx
export const Stack = () => (
  <svg viewBox="0 0 100 100">
    {[0, 1, 2, 3].map((i) => (
      <motion.rect key={i}
        x="25" y={20 + i * 18}
        width="50" height="15"
        fill={i === 0 ? "#DC2626" : "none"}
        stroke="currentColor"
        strokeWidth="1.5"
        animate={{ y: [20 + i * 18, 18 + i * 18, 20 + i * 18] }}
        transition={{ duration: 3, delay: i * 0.2, repeat: Infinity }}
      />
    ))}
  </svg>
);
```

---

## 4. CONNECTIONS

### bridge
**Concept:** Connecting sides
**Mechanic:** Gap with span being built

```tsx
export const Bridge = () => (
  <svg viewBox="0 0 100 100">
    {/* Pillars */}
    <rect x="15" y="40" width="15" height="40" fill="currentColor" opacity="0.5" />
    <rect x="70" y="40" width="15" height="40" fill="currentColor" opacity="0.5" />

    {/* Building bridge */}
    <motion.line x1="30" y1="45" x2="70" y2="45"
      stroke="#DC2626" strokeWidth="3"
      initial={{ pathLength: 0 }}
      animate={{ pathLength: 1 }}
      transition={{ duration: 3, repeat: Infinity, repeatDelay: 1 }}
    />

    {/* Particles crossing */}
    <motion.circle r="3" fill="#DC2626"
      animate={{ cx: [25, 75], cy: 42 }}
      transition={{ duration: 2, delay: 3, repeat: Infinity, repeatDelay: 2 }}
    />
  </svg>
);
```

### sync
**Concept:** Simultaneous action
**Mechanic:** Paired elements, same pulse

```tsx
export const Sync = () => (
  <svg viewBox="0 0 100 100">
    {/* Two circles synced */}
    <motion.circle cx="30" cy="50" r="15"
      fill="none" stroke="#DC2626" strokeWidth="2"
      animate={{ scale: [1, 1.2, 1] }}
      transition={{ duration: 2, repeat: Infinity }}
    />
    <motion.circle cx="70" cy="50" r="15"
      fill="none" stroke="#DC2626" strokeWidth="2"
      animate={{ scale: [1, 1.2, 1] }}
      transition={{ duration: 2, repeat: Infinity }}
    />

    {/* Connection line */}
    <line x1="45" y1="50" x2="55" y2="50" stroke="currentColor" strokeDasharray="2 2" />

    {/* Sync indicator */}
    <motion.path d="M48 45 L50 50 L52 45" fill="none" stroke="currentColor"
      animate={{ y: [0, -3, 0] }}
      transition={{ duration: 1, repeat: Infinity }}
    />
  </svg>
);
```

---

## 5. STATE & CONDITION

### active
**Concept:** Working, operational
**Mechanic:** Bright glow, pulse

```tsx
export const Active = () => (
  <svg viewBox="0 0 100 100">
    <defs>
      <filter id="active-glow">
        <feGaussianBlur stdDeviation="3" />
        <feMerge>
          <feMergeNode />
          <feMergeNode in="SourceGraphic" />
        </feMerge>
      </filter>
    </defs>

    <motion.circle cx="50" cy="50" r="20"
      fill="#DC2626"
      filter="url(#active-glow)"
      animate={{ scale: [1, 1.1, 1], opacity: [1, 0.8, 1] }}
      transition={{ duration: 1.5, repeat: Infinity }}
    />

    {/* Activity rays */}
    {[0, 60, 120, 180, 240, 300].map((angle, i) => (
      <motion.line key={i}
        x1="50" y1="50"
        x2={50 + Math.cos(angle * Math.PI / 180) * 35}
        y2={50 + Math.sin(angle * Math.PI / 180) * 35}
        stroke="#DC2626" strokeWidth="2"
        animate={{ opacity: [0.3, 1, 0.3] }}
        transition={{ duration: 1, delay: i * 0.1, repeat: Infinity }}
      />
    ))}
  </svg>
);
```

### error
**Concept:** Problem state
**Mechanic:** X mark, shake, red

```tsx
export const Error = () => (
  <svg viewBox="0 0 100 100">
    <motion.g
      animate={{ x: [-2, 2, -2, 0] }}
      transition={{ duration: 0.3, repeat: Infinity, repeatDelay: 2 }}
    >
      <circle cx="50" cy="50" r="30" fill="none" stroke="#DC2626" strokeWidth="3" />
      <line x1="35" y1="35" x2="65" y2="65" stroke="#DC2626" strokeWidth="3" />
      <line x1="65" y1="35" x2="35" y2="65" stroke="#DC2626" strokeWidth="3" />
    </motion.g>
  </svg>
);
```

---

## 6. TRANSFORMATION

### morph
**Concept:** Shape change
**Mechanic:** Path transformation

```tsx
export const Morph = () => (
  <svg viewBox="0 0 100 100">
    <motion.path
      fill="#DC2626"
      d="M30,50 L50,30 L70,50 L50,70 Z"
      animate={{
        d: [
          "M30,50 L50,30 L70,50 L50,70 Z",    // Diamond
          "M30,30 L70,30 L70,70 L30,70 Z",    // Square
          "M50,25 A25,25 0 1,1 50,75 A25,25 0 1,1 50,25", // Circle
          "M30,50 L50,30 L70,50 L50,70 Z",    // Back to diamond
        ]
      }}
      transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
    />
  </svg>
);
```

### merge
**Concept:** Two become one
**Mechanic:** Converging shapes

```tsx
export const Merge = () => (
  <svg viewBox="0 0 100 100">
    <motion.circle cx="30" cy="50" r="10" fill="currentColor"
      animate={{ cx: [30, 45] }}
      transition={{ duration: 2, repeat: Infinity, repeatType: "reverse" }}
    />
    <motion.circle cx="70" cy="50" r="10" fill="currentColor"
      animate={{ cx: [70, 55] }}
      transition={{ duration: 2, repeat: Infinity, repeatType: "reverse" }}
    />

    {/* Merged result */}
    <motion.circle cx="50" cy="50" r="15" fill="#DC2626"
      initial={{ scale: 0, opacity: 0 }}
      animate={{ scale: [0, 1, 0], opacity: [0, 1, 0] }}
      transition={{ duration: 2, delay: 1, repeat: Infinity, repeatDelay: 1 }}
    />
  </svg>
);
```

---

## 7. COGNITIVE

### focus
**Concept:** Concentrated attention
**Mechanic:** Crosshairs centering

```tsx
export const Focus = () => (
  <svg viewBox="0 0 100 100">
    {/* Outer ring */}
    <circle cx="50" cy="50" r="35" fill="none" stroke="currentColor" strokeWidth="1" opacity="0.3" />

    {/* Crosshairs */}
    <motion.g
      animate={{ scale: [1.2, 1, 1.2] }}
      transition={{ duration: 3, repeat: Infinity }}
    >
      <line x1="50" y1="20" x2="50" y2="40" stroke="#DC2626" strokeWidth="2" />
      <line x1="50" y1="60" x2="50" y2="80" stroke="#DC2626" strokeWidth="2" />
      <line x1="20" y1="50" x2="40" y2="50" stroke="#DC2626" strokeWidth="2" />
      <line x1="60" y1="50" x2="80" y2="50" stroke="#DC2626" strokeWidth="2" />
    </motion.g>

    {/* Center dot */}
    <motion.circle cx="50" cy="50" r="5" fill="#DC2626"
      animate={{ scale: [1, 1.3, 1] }}
      transition={{ duration: 1.5, repeat: Infinity }}
    />
  </svg>
);
```

### burnout
**Concept:** Energy depletion
**Mechanic:** Battery draining

```tsx
export const Burnout = () => (
  <svg viewBox="0 0 100 100">
    {/* Battery outline */}
    <rect x="25" y="30" width="50" height="40" rx="3"
      fill="none" stroke="currentColor" strokeWidth="2" />
    <rect x="75" y="42" width="5" height="16" rx="1"
      fill="currentColor" />

    {/* Draining level */}
    <motion.rect x="28" y="33" width="44" rx="1"
      fill="#DC2626"
      animate={{ height: [34, 5], y: [33, 62] }}
      transition={{ duration: 4, repeat: Infinity, repeatDelay: 1 }}
    />

    {/* Warning flash when low */}
    <motion.text x="50" y="55" textAnchor="middle"
      fill="#DC2626" fontSize="14" fontWeight="bold"
      animate={{ opacity: [0, 1, 0] }}
      transition={{ duration: 0.5, delay: 3, repeat: Infinity, repeatDelay: 4 }}
    >!</motion.text>
  </svg>
);
```

---

## 8. USAGE GUIDE

### Import Pattern

```tsx
import { Bottleneck, Focus, Network } from './metaphors';

const Section = ({ metaphorType }) => {
  const Metaphor = METAPHOR_MAP[metaphorType];
  return <Metaphor />;
};
```

### Styling

All metaphors use:
- `currentColor` for foreground (inherits from parent)
- `#DC2626` for accent/active elements
- `viewBox="0 0 100 100"` for consistent sizing

### Animation Timing

- **Ambient**: 2-6s duration, infinite repeat
- **State change**: 0.3-0.5s
- **Attention**: 1-2s with repeat

---

*72+ metaphors • AIM Style Toolkit*
