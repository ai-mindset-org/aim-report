# AIM Report Visual DNA

> Complete specification of the visual design system used in AIM Annual Report 2025.

---

## 1. COLOR SYSTEM

### Primary Palette

| Token | Hex | Usage |
|-------|-----|-------|
| `--accent` | `#DC2626` | Primary accent, CTAs, highlights, AI/machine elements |
| `--accent-glow` | `rgba(220, 38, 38, 0.4)` | Glow effects, shadows |
| `--bg-dark` | `#0A0A0A` | Dark mode background |
| `--bg-light` | `#F4F4F5` | Light mode background |
| `--text-primary` | `#F5F5F5` | Primary text (dark mode) |
| `--text-secondary` | `#737373` | Muted text, labels |
| `--text-dim` | `#333333` | Very subtle elements |
| `--border` | `#1A1A1A` | Subtle borders |

### CSS Variables

```css
:root {
  --color-bg: #0A0A0A;
  --color-text: #F5F5F5;
  --color-accent: #DC2626;
  --color-muted: #737373;
  --color-dim: #333333;
}

[data-theme="light"] {
  --color-bg: #F4F4F5;
  --color-text: #0A0A0A;
}
```

### Semantic Usage

- **Red (#DC2626)**: AI, machine, danger, action, emphasis
- **White (#F5F5F5)**: Human, clarity, primary content
- **Gray scale**: Hierarchy, depth, secondary information

---

## 2. TYPOGRAPHY

### Font Stack

```css
/* Primary - Roboto Flex (Variable) */
font-family: 'Roboto Flex', sans-serif;

/* Monospace - IBM Plex Mono */
font-family: 'IBM Plex Mono', monospace;
```

### Font Loading

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500;600;700&family=Roboto+Flex:opsz,slnt,wdth,wght@8..144,-10..0,25..151,100..1000&display=swap" rel="stylesheet">
```

### Variable Font Setup

```css
.vf-anim {
  font-family: 'Roboto Flex', sans-serif;
  --wght: 400;  /* Weight: 100-1000 */
  --wdth: 100;  /* Width: 25-151 */
  --slnt: 0;    /* Slant: -10 to 0 */
  --opsz: 14;   /* Optical size: 8-144 */
  font-variation-settings:
    "wght" var(--wght),
    "wdth" var(--wdth),
    "slnt" var(--slnt),
    "opsz" var(--opsz);
  will-change: font-variation-settings;
}
```

### Typography Scale

| Element | Size | Weight | Tracking | Transform |
|---------|------|--------|----------|-----------|
| Hero Title | `10vw` / `9vw` | 900 (black) | -0.04em | uppercase |
| Section Title | `5xl` - `8xl` | 700-900 | -0.02em | — |
| Subtitle | `sm` - `xl` | 400 | 0.25em | uppercase |
| Body | `base` - `lg` | 400 | normal | — |
| Label/Mono | `xs` - `sm` | 500-700 | 0.1-0.3em | uppercase |

### Typography Patterns

```css
/* Headlines - tight, heavy */
h1, h2, h3 {
  letter-spacing: -0.04em;
  font-variation-settings: "opsz" 144, "wght" 600;
}

/* Mono labels - wide, tech feel */
.font-mono {
  font-family: 'IBM Plex Mono', monospace;
  letter-spacing: 0.05em;
}

/* Status labels */
.label-status {
  font-size: 10px;
  text-transform: uppercase;
  letter-spacing: 0.2em;
  font-weight: 700;
}
```

---

## 3. LAYOUT SYSTEM

### Core Principles

1. **Full viewport sections** - `min-h-screen` for each major section
2. **Centered content** - `max-w-7xl mx-auto` for readability
3. **Generous padding** - `p-6 md:p-16` for breathing room
4. **Two-column grids** - Visual + Text side by side

### Grid Patterns

```tsx
// Hero - centered
<section className="h-screen flex items-center justify-center" />

// Content - split
<div className="grid lg:grid-cols-2 gap-12 items-center" />

// Cards
<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6" />
```

### Responsive Breakpoints

```css
/* Mobile first */
@media (min-width: 768px) { /* md */ }
@media (min-width: 1024px) { /* lg */ }
@media (min-width: 1280px) { /* xl */ }
```

---

## 4. EFFECTS & FILTERS

### Glow Effect

```css
/* Box glow */
box-shadow: 0 0 20px rgba(220, 38, 38, 0.4);

/* SVG glow filter */
filter: drop-shadow(0 0 5px #DC2626);
```

### SVG Filter Definitions

```xml
<defs>
  <!-- Glow -->
  <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
    <feGaussianBlur stdDeviation="3" result="blur"/>
    <feMerge>
      <feMergeNode in="blur"/>
      <feMergeNode in="SourceGraphic"/>
    </feMerge>
  </filter>

  <!-- Heavy blur -->
  <filter id="blur-heavy">
    <feGaussianBlur stdDeviation="6"/>
  </filter>

  <!-- Radial gradient -->
  <radialGradient id="glow-radial" cx="50%" cy="50%" r="50%">
    <stop offset="0%" stopColor="#DC2626" stopOpacity="0.2"/>
    <stop offset="100%" stopColor="transparent" stopOpacity="0"/>
  </radialGradient>
</defs>
```

### Backdrop Effects

```css
/* Frosted glass */
backdrop-filter: blur(10px);
background: rgba(0, 0, 0, 0.8);

/* Noise texture */
.bg-noise {
  position: fixed;
  inset: 0;
  pointer-events: none;
  z-index: 9999;
  opacity: 0.04;
  background-image: url("data:image/svg+xml,...");
}
```

### 3D Transforms

```css
/* Perspective container */
perspective: 1000px;
transform-style: preserve-3d;

/* Tilt on hover */
transform: rotateY(calc(var(--mouse-x) * 20deg)) rotateX(calc(var(--mouse-y) * -20deg));
```

---

## 5. ANIMATION PHILOSOPHY

### Timing Principles

| Animation Type | Duration | Easing |
|----------------|----------|--------|
| Ambient/background | 15-100s | linear |
| Scroll-driven | scrub 0.3-1 | power2.inOut |
| Interaction feedback | 0.2-0.5s | power2.out |
| Page transitions | 0.5-1s | power3.inOut |
| Hover states | 0.3s | ease-out |

### Motion Meaning

- **Rotation** = Continuous process, search
- **Pulse** = Life, attention, readiness
- **Float** = Ambient, organic, breathing
- **Dash flow** = Data transfer, connection
- **Scale** = Importance, focus
- **Blur** = Transition, uncertainty

### GSAP Patterns

```typescript
// Ambient - never stops
gsap.to(".spin-slow", {
  rotation: 360,
  transformOrigin: "center",
  duration: 60,
  repeat: -1,
  ease: "linear"
});

// Pulse - organic
gsap.to(".pulse", {
  scale: 1.1,
  opacity: 0.5,
  duration: 4,
  yoyo: true,
  repeat: -1,
  ease: "sine.inOut"
});

// Scroll-driven
gsap.to(element, {
  scrollTrigger: {
    trigger: container,
    start: "top top",
    end: "+=5000",
    pin: true,
    scrub: 0.3,
  },
  y: -200,
  opacity: 0,
});
```

---

## 6. COMPONENT PATTERNS

### Card with Glow

```tsx
<div className="relative p-6 bg-black/80 border border-white/10 backdrop-blur-md rounded-xl">
  {/* Corner decorations */}
  <div className="absolute top-0 left-0 w-3 h-3 border-t-2 border-l-2 border-white/40" />
  <div className="absolute top-0 right-0 w-3 h-3 border-t-2 border-r-2 border-white/40" />
  <div className="absolute bottom-0 left-0 w-3 h-3 border-b-2 border-l-2 border-white/40" />
  <div className="absolute bottom-0 right-0 w-3 h-3 border-b-2 border-r-2 border-white/40" />

  {content}
</div>
```

### Status Badge

```tsx
<span className="inline-block font-mono text-xs text-[#DC2626] font-bold px-3 py-1
  border border-[#DC2626]/30 bg-[#DC2626]/10 rounded uppercase tracking-widest">
  Layer 01: Analysis
</span>
```

### Button with Fill Animation

```tsx
<button className="group relative px-8 py-3 bg-transparent border border-white/30
  hover:border-white transition-all overflow-hidden">
  <div className="absolute inset-0 bg-white translate-y-full
    group-hover:translate-y-0 transition-transform duration-500" />
  <span className="relative font-mono text-sm tracking-widest text-white
    group-hover:text-black transition-colors">
    EXPLORE
  </span>
</button>
```

### Progress Bar

```tsx
<div className="h-1 bg-neutral-900 rounded-full overflow-hidden">
  <div
    className="h-full bg-[#DC2626] transition-all duration-300"
    style={{ width: `${progress}%` }}
  />
</div>
```

---

## 7. GRID PATTERNS

### Background Grid

```tsx
<svg className="absolute inset-0 w-full h-full opacity-20">
  <defs>
    <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
      <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#DC2626" strokeWidth="0.5" opacity="0.3"/>
    </pattern>
  </defs>
  <rect width="100%" height="100%" fill="url(#grid)" />
</svg>
```

### Dot Grid

```tsx
<pattern id="dots" width="20" height="20" patternUnits="userSpaceOnUse">
  <circle cx="10" cy="10" r="1" fill="currentColor" opacity="0.2"/>
</pattern>
```

---

## 8. INTERACTION PATTERNS

### Magnetic Hover

```typescript
const handleMouseMove = (e: React.MouseEvent) => {
  const { clientX, clientY, currentTarget } = e;
  const { width, height, left, top } = currentTarget.getBoundingClientRect();
  const x = (clientX - left) / width - 0.5;
  const y = (clientY - top) / height - 0.5;
  setTilt({ x, y });
};
```

### Scroll Snap

```css
.scroll-container {
  scroll-snap-type: y mandatory;
}

.scroll-section {
  scroll-snap-align: start;
}
```

### Keyboard Navigation

```typescript
useEffect(() => {
  const handleKeyDown = (e: KeyboardEvent) => {
    if (e.key === 'ArrowRight' || e.key === ' ') next();
    if (e.key === 'ArrowLeft') prev();
  };
  window.addEventListener('keydown', handleKeyDown);
  return () => window.removeEventListener('keydown', handleKeyDown);
}, []);
```

---

## 9. MOBILE CONSIDERATIONS

### Touch Targets

- Minimum 44x44px for all interactive elements
- Swipe navigation for horizontal content
- Simplified animations on mobile

### Responsive Typography

```css
/* Fluid scaling */
.hero-title {
  font-size: clamp(2rem, 10vw, 8rem);
}
```

### Reduced Motion

```css
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after {
    animation-duration: 0.01ms !important;
    transition-duration: 0.01ms !important;
  }
}
```

---

*Visual DNA extracted from AIM Report 2025 • AI Mindset Labs*
